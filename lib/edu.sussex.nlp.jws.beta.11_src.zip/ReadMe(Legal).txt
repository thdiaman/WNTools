Institution : University Of Sussex, Brighton, England, BN2.
Author : David Hope
Last Updated: 10/2008
Code: http://www.cogs.susx.ac.uk/users/drh21/

Source code may be freely adapted and/or used if reference is made to both the author and the institution (as denoted above).

